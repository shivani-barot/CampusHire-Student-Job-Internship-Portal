function calculateResult() {
    let entrepreneurship = Number(document.getElementById("entrepreneurship").value);
    let mathematics = Number(document.getElementById("mathematics").value);
    let aoc = Number(document.getElementById("aoc").value);
    let pp1 = Number(document.getElementById("pp1").value);
    let bwd = Number(document.getElementById("bwd").value);
    let es = Number(document.getElementById("es").value);

    let marks = [
        entrepreneurship,
        mathematics,
        aoc,
        pp1,
        bwd,
        es
    ];

    for (let mark of marks) {
        if (mark < 0 || mark > 100 || isNaN(mark)) {
            alert("Please enter valid marks between 0 and 100.");
            return;
        }
    }

    let total =
        entrepreneurship +
        mathematics +
        aoc +
        pp1 +
        bwd +
        es;

    let percentage = (total / 600) * 100;

    let grade;

    if (percentage >= 90) {
        grade = "A+";
    } else if (percentage >= 80) {
        grade = "A";
    } else if (percentage >= 70) {
        grade = "B";
    } else if (percentage >= 60) {
        grade = "C";
    } else if (percentage >= 50) {
        grade = "D";
    } else {
        grade = "F";
    }

    let status;

    if (
        entrepreneurship >= 35 &&
        mathematics >= 35 &&
        aoc >= 35 &&
        pp1 >= 35 &&
        bwd >= 35 &&
        es >= 35
    ) {
        status = "PASS";
    } else {
        status = "FAIL";
    }

    document.getElementById("total").textContent = total;
    document.getElementById("percentage").textContent = percentage.toFixed(2);
    document.getElementById("grade").textContent = grade;
    document.getElementById("status").textContent = status;
    document.getElementById("result").style.display = "block";

    if (status === "PASS") {
        document.getElementById("status").className = "pass";
    } else {
        document.getElementById("status").className = "fail";
    }
}
