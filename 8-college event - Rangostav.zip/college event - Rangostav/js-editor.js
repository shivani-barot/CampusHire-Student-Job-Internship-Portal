const audio = document.getElementById("promo-audio");
const video = document.getElementById("event-video");
const status = document.getElementById("status");
const speed = document.getElementById("speed");
const loopBtn = document.getElementById("loop-btn");
const fullBtn = document.getElementById("full-btn");

// 1. Only one media file plays at a time
audio.addEventListener("play", function () {
  video.pause();
  status.textContent = "Playing the promotional audio.";
});

video.addEventListener("play", function () {
  audio.pause();
  status.textContent = "Playing the event video.";
});

video.addEventListener("pause", function () {
  if (!video.ended) status.textContent = "Video paused.";
});

audio.addEventListener("pause", function () {
  if (!audio.ended) status.textContent = "Audio paused.";
});

audio.addEventListener("ended", function () { status.textContent = "Audio finished."; });
video.addEventListener("ended", function () { status.textContent = "Video finished."; });

// 2. Video playback speed
speed.addEventListener("change", function () {
  video.playbackRate = parseFloat(speed.value);
});

// 3. Loop the video
loopBtn.addEventListener("click", function () {
  video.loop = !video.loop;
  loopBtn.setAttribute("aria-pressed", String(video.loop));
  loopBtn.textContent = video.loop ? "Loop: on" : "Loop: off";
});

// 4. Full screen
fullBtn.addEventListener("click", function () {
  if (video.requestFullscreen) {
    video.requestFullscreen();
  } else if (video.webkitEnterFullscreen) {
    video.webkitEnterFullscreen();
  }
});

// 5. Message if a media file cannot be loaded
[audio, video].forEach(function (media) {
  media.addEventListener("error", function () {
    status.textContent = "Sorry, a media file could not be loaded. Check the file names.";
  }, true);
});

// Footer year
document.getElementById("year").textContent = new Date().getFullYear();
