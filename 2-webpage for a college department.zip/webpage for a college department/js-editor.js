// 1. Mobile menu toggle
const menuBtn = document.getElementById("menu-btn");
const navLinks = document.getElementById("nav-links");

menuBtn.addEventListener("click", function () {
  const isOpen = navLinks.classList.toggle("open");
  menuBtn.setAttribute("aria-expanded", String(isOpen));
});

navLinks.addEventListener("click", function (e) {
  if (e.target.tagName === "A") {
    navLinks.classList.remove("open");
    menuBtn.setAttribute("aria-expanded", "false");
  }
});

// 2. Highlight the nav link of the section being viewed
const sections = document.querySelectorAll("main section");
const links = document.querySelectorAll("#nav-links a");

function updateActiveLink() {
  let current = "";
  sections.forEach(function (section) {
    if (window.scrollY >= section.offsetTop - 120) current = section.id;
  });
  links.forEach(function (link) {
    link.classList.toggle("active", link.getAttribute("href") === "#" + current);
  });
}

// 3. Back-to-top button
const toTop = document.getElementById("to-top");

function updateToTop() {
  toTop.hidden = window.scrollY < 400;
}

toTop.addEventListener("click", function () {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

window.addEventListener("scroll", function () {
  updateActiveLink();
  updateToTop();
});

// 4. Current year in footer
document.getElementById("year").textContent = new Date().getFullYear();

updateActiveLink();
updateToTop();
