# College Website - Deployment Guide

## Structure
```
college-site/
  index.html  about.html  courses.html  contact.html
  css/style.css
  js/script.js
```
`index.html` must stay in the root folder: web servers load it by default.

## 1. Test locally
Open `index.html` in a browser (needs internet for the Bootstrap CDN).

## 2. Option A - Shared hosting (cPanel / FTP)
1. Buy/choose hosting and a domain; get FTP details (host, username, password).
2. Open FileZilla -> enter host, username, password, port 21 -> Quickconnect.
3. On the server, open `public_html/` (or `www/`).
4. Upload ALL files and folders (keep the css/ and js/ folders).
5. Visit `http://yourdomain.com` in a browser.
   (cPanel alternative: File Manager -> public_html -> Upload -> Extract the zip.)

## 3. Option B - GitHub Pages (free)
1. Create a GitHub repository (e.g. `college-site`).
2. Upload all files to the repository root.
3. Settings -> Pages -> Source: "Deploy from a branch" -> main / (root) -> Save.
4. After about a minute, open `https://<username>.github.io/college-site/`.

## 4. Option C - Local web server (XAMPP, for lab demo)
1. Install XAMPP and start Apache.
2. Copy the folder to `C:\xampp\htdocs\college-site`.
3. Open `http://localhost/college-site/`.

## 5. Checklist
- File names are lowercase and match links exactly (Linux servers are case-sensitive).
- Test on mobile and refresh with Ctrl+F5 after re-uploading.
