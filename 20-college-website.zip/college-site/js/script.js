// Footer year
document.getElementById("year").textContent = new Date().getFullYear();

// Highlight current page in navbar
const current = location.pathname.split("/").pop() || "index.html";
document.querySelectorAll(".nav-link").forEach(function (link) {
  if (link.getAttribute("href") === current) link.classList.add("active");
});

// Simple visit counter (stored in this browser only)
const counter = document.getElementById("visitCount");
if (counter) {
  let visits = 1;
  try {
    visits = Number(localStorage.getItem("visits") || 0) + 1;
    localStorage.setItem("visits", visits);
  } catch (e) {}
  counter.textContent = visits;
}

// Contact form validation
const form = document.getElementById("contactForm");
if (form) {
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    const name = document.getElementById("cName");
    const email = document.getElementById("cEmail");
    const msg = document.getElementById("cMsg");
    const checks = [
      [name, name.value.trim() !== ""],
      [email, /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())],
      [msg, msg.value.trim().length >= 10]
    ];
    let ok = true;
    checks.forEach(function (c) {
      c[0].classList.toggle("is-invalid", !c[1]);
      c[0].classList.toggle("is-valid", c[1]);
      if (!c[1]) ok = false;
    });
    document.getElementById("formSuccess").classList.toggle("d-none", !ok);
    if (ok) {
      form.reset();
      checks.forEach(function (c) { c[0].classList.remove("is-valid"); });
    }
  });
}
