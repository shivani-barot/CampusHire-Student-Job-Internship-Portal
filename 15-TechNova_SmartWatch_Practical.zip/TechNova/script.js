function buyNow() {
    alert(
        "Thank you for choosing TechNova! ⌚\n\n" +
        "Your SmartWatch order process has started."
    );
}

function changeColor(color) {
    const image = document.querySelector(".product-image img");

    if (color === "black") {
        image.style.filter = "grayscale(0.8) contrast(1.2)";
    } else if (color === "blue") {
        image.style.filter = "hue-rotate(180deg) saturate(1.4)";
    } else if (color === "orange") {
        image.style.filter = "sepia(0.5) saturate(2)";
    }
}
