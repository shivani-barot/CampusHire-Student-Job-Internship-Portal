// Grade scale: minimum percentage for each grade
function getGrade(percent) {
  if (percent >= 90) return "A+";
  if (percent >= 80) return "A";
  if (percent >= 70) return "B+";
  if (percent >= 60) return "B";
  if (percent >= 50) return "C";
  if (percent >= 40) return "D";
  return "F";
}

const rows = document.querySelectorAll("#marks-table tbody tr");
const subjectCount = 6;
const maxPerSubject = 100;

function recalculate() {
  const subjectSums = new Array(subjectCount).fill(0);
  let totalSum = 0;
  let percentSum = 0;
  let bestTotal = -1;

  rows.forEach(function (row) {
    const markCells = row.querySelectorAll(".mark");
    let total = 0;

    markCells.forEach(function (cell, i) {
      let value = parseFloat(cell.textContent);
      if (isNaN(value)) value = 0;
      value = Math.min(Math.max(value, 0), maxPerSubject);
      total += value;
      subjectSums[i] += value;
      cell.classList.toggle("low", value < 35);
    });

    const percent = total / (subjectCount * maxPerSubject) * 100;
    const grade = getGrade(percent);

    row.querySelector(".total").textContent = total;
    row.querySelector(".percent").textContent = percent.toFixed(2) + "%";

    const gradeCell = row.querySelector(".grade");
    gradeCell.textContent = grade;
    gradeCell.className = "grade grade-" + grade.replace("+", "plus");

    totalSum += total;
    percentSum += percent;
    row.dataset.total = total;
    if (total > bestTotal) bestTotal = total;
  });

  // Highlight the topper row(s)
  rows.forEach(function (row) {
    row.classList.toggle("topper", Number(row.dataset.total) === bestTotal);
  });

  // Class averages in the footer
  document.querySelectorAll("#marks-table tfoot .avg").forEach(function (cell, i) {
    cell.textContent = (subjectSums[i] / rows.length).toFixed(1);
  });
  document.getElementById("avg-total").textContent = (totalSum / rows.length).toFixed(1);
  document.getElementById("avg-percent").textContent = (percentSum / rows.length).toFixed(2) + "%";
}

// Edit-marks toggle
const editBtn = document.getElementById("edit-btn");
const editHint = document.getElementById("edit-hint");

editBtn.addEventListener("click", function () {
  const editing = editBtn.getAttribute("aria-pressed") !== "true";
  editBtn.setAttribute("aria-pressed", String(editing));
  editBtn.textContent = editing ? "Done editing" : "Edit marks";
  editHint.hidden = !editing;
  document.querySelectorAll(".mark").forEach(function (cell) {
    cell.contentEditable = editing ? "true" : "false";
  });
});

document.getElementById("marks-table").addEventListener("input", recalculate);

// Footer year
document.getElementById("year").textContent = new Date().getFullYear();

recalculate();
