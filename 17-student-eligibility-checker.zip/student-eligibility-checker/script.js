function checkEligibility() {

    // Get values from input fields

    let age =
        Number(document.getElementById("age").value);

    let attendance =
        Number(document.getElementById("attendance").value);

    let marks =
        Number(document.getElementById("marks").value);


    // Check whether fields are empty or invalid

    if (
        age <= 0 ||
        attendance < 0 ||
        attendance > 100 ||
        marks < 0 ||
        marks > 100
    ) {

        alert(
            "Please enter valid details."
        );

        return;
    }


    // Eligibility conditions

    if (
        age >= 17 &&
        attendance >= 75 &&
        marks >= 40
    ) {

        alert(
            "Congratulations! 🎉\n\n" +
            "The student is ELIGIBLE " +
            "for the examination/admission."
        );

    }

    else if (age < 17) {

        alert(
            "The student is NOT ELIGIBLE.\n\n" +
            "Minimum age requirement is 17 years."
        );

    }

    else if (attendance < 75) {

        alert(
            "The student is NOT ELIGIBLE.\n\n" +
            "Minimum attendance required is 75%."
        );

    }

    else if (marks < 40) {

        alert(
            "The student is NOT ELIGIBLE.\n\n" +
            "Minimum marks required are 40%."
        );

    }

    else {

        alert(
            "The student is NOT ELIGIBLE " +
            "for the examination/admission."
        );
    }
}
