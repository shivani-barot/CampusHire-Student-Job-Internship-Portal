// Event start date and time (15 Nov 2026, 10:00 AM)
const eventDate = new Date(2026, 10, 15, 10, 0, 0);
const countdownEl = document.getElementById("countdown");

function updateCountdown() {
  const diff = eventDate - new Date();

  if (diff <= 0) {
    countdownEl.textContent = "The event has started or is over. Thank you for joining!";
    return;
  }

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((diff / (1000 * 60)) % 60);

  countdownEl.textContent =
    "Starts in " + days + " days, " + hours + " hours, " + minutes + " minutes";
}

updateCountdown();
setInterval(updateCountdown, 60000);

// Footer year
document.getElementById("year").textContent = new Date().getFullYear();
