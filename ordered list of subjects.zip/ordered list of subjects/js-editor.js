// Filter subjects by type: all / theory / practical
const buttons = document.querySelectorAll(".filter");
const typedItems = document.querySelectorAll("[data-type]");
const subjectItems = document.querySelectorAll(".subject-list > li");

function applyFilter(type) {
  // Show or hide each theory/practical item and its detail card
  typedItems.forEach(function (item) {
    const match = type === "all" || item.dataset.type === type;
    item.classList.toggle("is-hidden", !match);
  });

  // Hide a whole subject if none of its nested items are visible
  subjectItems.forEach(function (li) {
    const visible = li.querySelectorAll("li:not(.is-hidden)").length;
    li.classList.toggle("is-hidden", visible === 0);
  });
}

buttons.forEach(function (button) {
  button.addEventListener("click", function () {
    buttons.forEach(function (b) { b.classList.remove("active"); });
    button.classList.add("active");
    applyFilter(button.dataset.filter);
  });
});

// Footer year
document.getElementById("year").textContent = new Date().getFullYear();
