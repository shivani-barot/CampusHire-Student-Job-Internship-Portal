function filterMenu(category, button) {
    const items = document.querySelectorAll(".food-item");
    const buttons = document.querySelectorAll(".category-btn");

    buttons.forEach(btn => btn.classList.remove("active"));
    button.classList.add("active");

    items.forEach(item => {
        if (category === "all" || item.classList.contains(category)) {
            item.style.display = "block";
        } else {
            item.style.display = "none";
        }
    });
}

function orderFood(foodName) {
    alert(
        "Thank you for choosing FoodieHub! 🍴\n\n" +
        foodName +
        " has been selected."
    );
}
