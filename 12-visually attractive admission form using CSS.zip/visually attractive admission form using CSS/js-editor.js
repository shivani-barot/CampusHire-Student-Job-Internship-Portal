const form = document.getElementById("admission");
const message = document.getElementById("message");

// 1. Allow only digits in the phone and pincode fields
["phone", "pin"].forEach(function (id) {
  document.getElementById(id).addEventListener("input", function (e) {
    e.target.value = e.target.value.replace(/\D/g, "");
  });
});

// 2. Validate on submit and show a confirmation message
form.addEventListener("submit", function (event) {
  event.preventDefault();
  form.classList.add("was-validated");

  if (!form.checkValidity()) {
    message.hidden = true;
    form.reportValidity();
    return;
  }

  const number = "MU" + Math.floor(100000 + Math.random() * 900000);
  const name = document.getElementById("name").value.trim();
  message.textContent =
    "Thank you, " + name + "! Your application has been received. Application number: " + number + ".";
  message.hidden = false;
  message.scrollIntoView({ behavior: "smooth", block: "center" });
});

// 3. Reset clears the validation colours and the message
form.addEventListener("reset", function () {
  form.classList.remove("was-validated");
  message.hidden = true;
});

// Footer year
document.getElementById("year-now").textContent = new Date().getFullYear();
