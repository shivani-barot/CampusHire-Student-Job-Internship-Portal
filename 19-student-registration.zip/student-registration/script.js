// Get form
const form = document.getElementById("registrationForm");

// Validate Name
function validateName() {
    const name = document.getElementById("name");
    const error = document.getElementById("nameError");
    const namePattern = /^[A-Za-z ]+$/;

    if (name.value.trim() === "") {
        error.textContent = "Name is required.";
        name.classList.add("error-input");
        return false;
    }

    if (!namePattern.test(name.value.trim())) {
        error.textContent = "Name should contain only letters.";
        name.classList.add("error-input");
        return false;
    }

    error.textContent = "";
    name.classList.remove("error-input");
    name.classList.add("valid-input");
    return true;
}

// Validate Email
function validateEmail() {
    const email = document.getElementById("email");
    const error = document.getElementById("emailError");
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (email.value.trim() === "") {
        error.textContent = "Email is required.";
        email.classList.add("error-input");
        return false;
    }

    if (!emailPattern.test(email.value.trim())) {
        error.textContent = "Please enter a valid email address.";
        email.classList.add("error-input");
        return false;
    }

    error.textContent = "";
    email.classList.remove("error-input");
    email.classList.add("valid-input");
    return true;
}

// Validate Password
function validatePassword() {
    const password = document.getElementById("password");
    const error = document.getElementById("passwordError");

    if (password.value === "") {
        error.textContent = "Password is required.";
        password.classList.add("error-input");
        return false;
    }

    if (password.value.length < 6) {
        error.textContent = "Password must be at least 6 characters.";
        password.classList.add("error-input");
        return false;
    }

    error.textContent = "";
    password.classList.remove("error-input");
    password.classList.add("valid-input");
    return true;
}

// Validate Confirm Password
function validateConfirmPassword() {
    const password = document.getElementById("password");
    const confirmPassword = document.getElementById("confirmPassword");
    const error = document.getElementById("confirmPasswordError");

    if (confirmPassword.value === "") {
        error.textContent = "Please confirm your password.";
        confirmPassword.classList.add("error-input");
        return false;
    }

    if (password.value !== confirmPassword.value) {
        error.textContent = "Passwords do not match.";
        confirmPassword.classList.add("error-input");
        return false;
    }

    error.textContent = "";
    confirmPassword.classList.remove("error-input");
    confirmPassword.classList.add("valid-input");
    return true;
}

// Validate Mobile
function validateMobile() {
    const mobile = document.getElementById("mobile");
    const error = document.getElementById("mobileError");
    const mobilePattern = /^[0-9]{10}$/;

    if (!mobilePattern.test(mobile.value)) {
        error.textContent = "Enter a valid 10-digit mobile number.";
        mobile.classList.add("error-input");
        return false;
    }

    error.textContent = "";
    mobile.classList.remove("error-input");
    mobile.classList.add("valid-input");
    return true;
}

// Validate Date of Birth
function validateDOB() {
    const dob = document.getElementById("dob");
    const error = document.getElementById("dobError");

    if (dob.value === "") {
        error.textContent = "Date of birth is required.";
        dob.classList.add("error-input");
        return false;
    }

    error.textContent = "";
    dob.classList.remove("error-input");
    dob.classList.add("valid-input");
    return true;
}

// Validate Gender
function validateGender() {
    const gender = document.querySelector('input[name="gender"]:checked');
    const error = document.getElementById("genderError");

    if (!gender) {
        error.textContent = "Please select your gender.";
        return false;
    }

    error.textContent = "";
    return true;
}

// Validate Course
function validateCourse() {
    const course = document.getElementById("course");
    const error = document.getElementById("courseError");

    if (course.value === "") {
        error.textContent = "Please select a course.";
        course.classList.add("error-input");
        return false;
    }

    error.textContent = "";
    course.classList.remove("error-input");
    course.classList.add("valid-input");
    return true;
}

// Validate Address
function validateAddress() {
    const address = document.getElementById("address");
    const error = document.getElementById("addressError");

    if (address.value.trim() === "") {
        error.textContent = "Address is required.";
        address.classList.add("error-input");
        return false;
    }

    error.textContent = "";
    address.classList.remove("error-input");
    address.classList.add("valid-input");
    return true;
}

// Validate Terms
function validateTerms() {
    const terms = document.getElementById("terms");
    const error = document.getElementById("termsError");

    if (!terms.checked) {
        error.textContent = "Please accept the terms and conditions.";
        return false;
    }

    error.textContent = "";
    return true;
}

// Form Submit Event
form.addEventListener("submit", function (event) {

    // Stop actual form submission
    event.preventDefault();

    // Validate all fields
    const validName = validateName();
    const validEmail = validateEmail();
    const validPassword = validatePassword();
    const validConfirmPassword = validateConfirmPassword();
    const validMobile = validateMobile();
    const validDOB = validateDOB();
    const validGender = validateGender();
    const validCourse = validateCourse();
    const validAddress = validateAddress();
    const validTerms = validateTerms();

    // Check all validation results
    if (
        validName &&
        validEmail &&
        validPassword &&
        validConfirmPassword &&
        validMobile &&
        validDOB &&
        validGender &&
        validCourse &&
        validAddress &&
        validTerms
    ) {

        document.getElementById("successMessage").style.display = "block";

        // Display success dialog
        alert(
            "Registration Successful! 🎉\n\n" +
            "Welcome to the student registration portal."
        );

        // Reset form
        form.reset();

        // Clear green "valid" styling after reset
        document.querySelectorAll(".valid-input").forEach(function (el) {
            el.classList.remove("valid-input");
        });

    } else {

        document.getElementById("successMessage").style.display = "none";
    }

});

// Input Events
document.getElementById("name").addEventListener("input", validateName);
document.getElementById("email").addEventListener("input", validateEmail);
document.getElementById("password").addEventListener("input", validatePassword);
document.getElementById("confirmPassword").addEventListener("input", validateConfirmPassword);
document.getElementById("mobile").addEventListener("input", validateMobile);
document.getElementById("dob").addEventListener("change", validateDOB);
document.getElementById("course").addEventListener("change", validateCourse);
document.getElementById("address").addEventListener("input", validateAddress);
document.getElementById("terms").addEventListener("change", validateTerms);

// Gender Change Event
const genderOptions = document.querySelectorAll('input[name="gender"]');

genderOptions.forEach(function (gender) {
    gender.addEventListener("change", validateGender);
});
