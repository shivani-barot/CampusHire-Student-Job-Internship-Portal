// Get the Canvas element
const canvas = document.getElementById("myCanvas");

// Get the 2D drawing context
const ctx = canvas.getContext("2d");

// 1. Draw Rectangle
ctx.fillStyle = "#1499a8";
ctx.fillRect(60, 60, 180, 100);

ctx.strokeStyle = "#123b5d";
ctx.lineWidth = 4;
ctx.strokeRect(60, 60, 180, 100);

// 2. Draw Circle
ctx.beginPath();
ctx.arc(430, 110, 70, 0, 2 * Math.PI);
ctx.fillStyle = "#f4a623";
ctx.fill();
ctx.strokeStyle = "#123b5d";
ctx.lineWidth = 4;
ctx.stroke();

// 3. Draw Line
ctx.beginPath();
ctx.moveTo(100, 250);
ctx.lineTo(600, 250);
ctx.strokeStyle = "#123b5d";
ctx.lineWidth = 5;
ctx.stroke();

// 4. Draw Triangle
ctx.beginPath();
ctx.moveTo(350, 280);
ctx.lineTo(280, 350);
ctx.lineTo(420, 350);
ctx.closePath();

ctx.fillStyle = "#7b3f98";
ctx.fill();

ctx.strokeStyle = "#123b5d";
ctx.lineWidth = 3;
ctx.stroke();

// 5. Draw Text
ctx.font = "bold 26px Arial";
ctx.fillStyle = "#123b5d";
ctx.textAlign = "center";
ctx.fillText("HTML5 Canvas", 350, 390);
