// 1. Time-based greeting
function setGreeting() {
  const hour = new Date().getHours();
  let message = "Good evening";
  if (hour < 12) message = "Good morning";
  else if (hour < 17) message = "Good afternoon";
  document.getElementById("greeting").textContent = message + "! Welcome to my page.";
}

// 2. Current year in footer
function setYear() {
  document.getElementById("year").textContent = new Date().getFullYear();
}

// 3. Dark / light mode toggle
function setupThemeToggle() {
  const button = document.getElementById("theme-toggle");
  const root = document.documentElement;

  button.addEventListener("click", function () {
    const isDark = root.getAttribute("data-theme") === "dark";
    root.setAttribute("data-theme", isDark ? "light" : "dark");
    button.textContent = isDark ? "Dark mode" : "Light mode";
    button.setAttribute("aria-pressed", String(!isDark));
  });
}

// 4. Highlight a hobby when clicked
function setupHobbies() {
  document.querySelectorAll(".hobbies li").forEach(function (item) {
    item.addEventListener("click", function () {
      item.classList.toggle("active");
    });
  });
}

// 5. Show a simple placeholder if photo.jpg is missing
function setupPhotoFallback() {
  const img = document.getElementById("profile-photo");
  img.addEventListener("error", function () {
    const svg =
      "<svg xmlns='http://www.w3.org/2000/svg' width='220' height='220'>" +
      "<rect width='100%' height='100%' fill='#c9dad6'/>" +
      "<circle cx='110' cy='85' r='38' fill='#0f7b6c'/>" +
      "<ellipse cx='110' cy='190' rx='65' ry='50' fill='#0f7b6c'/></svg>";
    img.src = "data:image/svg+xml;utf8," + encodeURIComponent(svg);
  }, { once: true });
}

document.addEventListener("DOMContentLoaded", function () {
  setGreeting();
  setYear();
  setupThemeToggle();
  setupHobbies();
  setupPhotoFallback();
});
