// 1. Mobile menu toggle
const menuBtn = document.getElementById("menu-btn");
const navLinks = document.getElementById("nav-links");

menuBtn.addEventListener("click", function () {
  const isOpen = navLinks.classList.toggle("open");
  menuBtn.setAttribute("aria-expanded", String(isOpen));
});

navLinks.addEventListener("click", function (e) {
  if (e.target.tagName === "A") {
    navLinks.classList.remove("open");
    menuBtn.setAttribute("aria-expanded", "false");
  }
});

// 2. Highlight the nav link for the section being viewed
const sections = document.querySelectorAll("main section");
const links = document.querySelectorAll("#nav-links a");

function updateActiveLink() {
  let current = "";
  sections.forEach(function (section) {
    if (window.scrollY >= section.offsetTop - 140) current = section.id;
  });
  links.forEach(function (link) {
    link.classList.toggle("active", link.getAttribute("href") === "#" + current);
  });
}
window.addEventListener("scroll", updateActiveLink);
updateActiveLink();

// 3. Fill the skill bars when the Skills section comes into view
const fills = document.querySelectorAll(".fill");

function fillBars() {
  fills.forEach(function (bar) {
    bar.style.width = bar.dataset.level + "%";
  });
}

if ("IntersectionObserver" in window) {
  const observer = new IntersectionObserver(function (entries) {
    if (entries[0].isIntersecting) {
      fillBars();
      observer.disconnect();
    }
  }, { threshold: 0.3 });
  observer.observe(document.getElementById("skills"));
} else {
  fillBars();
}

// 4. Footer year
document.getElementById("year").textContent = new Date().getFullYear();
