// 1. Highlight the nav link of the section being viewed
const sections = document.querySelectorAll("header[id], section[id]");
const navLinks = document.querySelectorAll("#navMenu .nav-link");

function updateActiveLink() {
  let current = "home";
  sections.forEach(function (section) {
    if (window.scrollY >= section.offsetTop - 120) current = section.id;
  });
  navLinks.forEach(function (link) {
    link.classList.toggle("active", link.getAttribute("href") === "#" + current);
  });
}
window.addEventListener("scroll", updateActiveLink);
updateActiveLink();

// 2. Close the mobile menu after clicking a link
document.querySelectorAll("#navMenu a").forEach(function (link) {
  link.addEventListener("click", function () {
    const menu = document.getElementById("navMenu");
    if (menu.classList.contains("show") && window.bootstrap) {
      window.bootstrap.Collapse.getOrCreateInstance(menu).hide();
    }
  });
});

// 3. Contact form: simple check and thank-you message
const form = document.getElementById("contact-form");
const msg = document.getElementById("form-msg");

form.addEventListener("submit", function (event) {
  event.preventDefault();
  if (!form.checkValidity()) {
    form.reportValidity();
    return;
  }
  msg.textContent = "Thank you, " + document.getElementById("c-name").value.trim() +
    "! We have received your message and will contact you soon.";
  msg.classList.remove("d-none");
  form.reset();
});

// 4. Footer year
document.getElementById("year").textContent = new Date().getFullYear();
