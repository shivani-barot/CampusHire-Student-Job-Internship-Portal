const locateBtn = document.getElementById("locate-btn");
const campusBtn = document.getElementById("campus-btn");
const statusEl = document.getElementById("geo-status");
const table = document.getElementById("geo-table");
const mapFrame = document.getElementById("map-frame");
const mapCaption = document.getElementById("map-caption");
const directions = document.getElementById("directions");
const directionsLink = document.getElementById("directions-link");

const CAMPUS_QUERY = "Marwadi University, Rajkot";

function setStatus(message, type) {
  statusEl.textContent = message;
  statusEl.className = "status" + (type ? " " + type : "");
}

// Called when the browser gives us the position
function onSuccess(position) {
  const lat = position.coords.latitude;
  const lon = position.coords.longitude;
  const accuracy = Math.round(position.coords.accuracy);

  document.getElementById("lat").textContent = lat.toFixed(6) + "\u00B0";
  document.getElementById("lon").textContent = lon.toFixed(6) + "\u00B0";
  document.getElementById("acc").textContent = "about " + accuracy + " metres";
  document.getElementById("time").textContent = new Date(position.timestamp).toLocaleTimeString();
  table.hidden = false;

  setStatus("Location found!", "ok");
  locateBtn.disabled = false;

  // Show the user's position on the map inside the iframe
  mapFrame.src = "https://maps.google.com/maps?q=" + lat + "," + lon + "&z=15&output=embed";
  mapCaption.textContent = "Showing: your current location";

  // Link to directions from the user to the campus
  directionsLink.href =
    "https://www.google.com/maps/dir/?api=1&origin=" + lat + "," + lon +
    "&destination=" + encodeURIComponent(CAMPUS_QUERY);
  directions.hidden = false;
}

// Called when something goes wrong
function onError(error) {
  let message = "Could not get your location.";
  if (error.code === error.PERMISSION_DENIED) {
    message = "Permission denied. Please allow location access in your browser and try again.";
  } else if (error.code === error.POSITION_UNAVAILABLE) {
    message = "Your location is not available right now.";
  } else if (error.code === error.TIMEOUT) {
    message = "The request timed out. Please try again.";
  }
  setStatus(message, "error");
  locateBtn.disabled = false;
}

locateBtn.addEventListener("click", function () {
  if (!("geolocation" in navigator)) {
    setStatus("Geolocation is not supported by your browser.", "error");
    return;
  }
  setStatus("Finding your location\u2026");
  locateBtn.disabled = true;

  navigator.geolocation.getCurrentPosition(onSuccess, onError, {
    enableHighAccuracy: true,
    timeout: 10000,
    maximumAge: 0
  });
});

// Switch the map back to the campus
campusBtn.addEventListener("click", function () {
  mapFrame.src = "https://maps.google.com/maps?q=" + encodeURIComponent(CAMPUS_QUERY) + "&z=15&output=embed";
  mapCaption.textContent = "Showing: Marwadi University, Rajkot";
});

document.getElementById("year").textContent = new Date().getFullYear();
