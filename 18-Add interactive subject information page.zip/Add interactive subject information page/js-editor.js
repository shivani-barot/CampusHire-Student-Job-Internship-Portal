/* ==========================================================
   Subject Explorer: arrays, functions and events
   ========================================================== */

// ---------- 1. DATA: an array of objects ----------
const subjects = [
  {
    id: 1, code: "C04ID0001", name: "Entrepreneurship", type: "Theory",
    description: "Introduces the mindset, skills and steps involved in starting and running a business.",
    topics: ["Entrepreneurial mindset", "Idea generation", "Business plan basics", "Startup funding", "Marketing basics"]
  },
  {
    id: 2, code: "C05BC3101", name: "Mathematics 1", type: "Theory",
    description: "Covers the mathematical foundations needed for computer applications.",
    topics: ["Sets and relations", "Functions", "Matrices", "Limits and continuity", "Basic differentiation"]
  },
  {
    id: 3, code: "C05BC3102", name: "Architectural Organization of Computers (AOC)", type: "Theory",
    description: "Explains how a computer is built: processor, memory, input/output and how they work together.",
    topics: ["Number systems", "Logic gates", "CPU organization", "Memory hierarchy", "Input/output organization"]
  },
  {
    id: 4, code: "C05BC3103", name: "Programming Practices 1 (C)", type: "Practical",
    description: "Hands-on practice in C programming: writing, compiling and debugging programs.",
    topics: ["Variables and data types", "Operators", "Decision making", "Loops", "Functions and arrays"]
  },
  {
    id: 5, code: "C05BC3104", name: "Basic of Web Development (Theory)", type: "Theory",
    description: "Concepts behind web pages and websites, using HTML, CSS and JavaScript.",
    topics: ["HTML5 elements", "CSS styling", "Forms and tables", "JavaScript basics", "Responsive design"]
  },
  {
    id: 6, code: "C05BC0203", name: "Basic of Web Development (Practical)", type: "Practical",
    description: "Practical web pages and a final project, submitted on GitHub.",
    topics: ["Personal introduction page", "Tables and forms", "CSS layouts", "JavaScript interactivity", "Project on GitHub"]
  },
  {
    id: 7, code: "C05BC3105", name: "Environmental Science (ES)", type: "Theory",
    description: "Studies the environment, natural resources and how people can protect them.",
    topics: ["Ecosystems", "Natural resources", "Pollution", "Biodiversity", "Sustainable development"]
  }
];

// ---------- 2. STATE ----------
let selectedId = null;          // id of the subject being shown
const studied = [];             // array of ids marked as studied

// ---------- 3. ELEMENTS ----------
const listEl = document.getElementById("subject-list");
const searchEl = document.getElementById("search");
const filterEl = document.getElementById("type-filter");
const countEl = document.getElementById("count");
const placeholderEl = document.getElementById("placeholder");
const detailEl = document.getElementById("detail");
const studiedBox = document.getElementById("studied-box");

// ---------- 4. FUNCTIONS ----------

// Return the subjects that match the search text and type filter
function getVisibleSubjects() {
  const text = searchEl.value.trim().toLowerCase();
  const type = filterEl.value;

  return subjects.filter(function (s) {
    const matchesText = s.name.toLowerCase().includes(text) || s.code.toLowerCase().includes(text);
    const matchesType = type === "all" || s.type === type;
    return matchesText && matchesType;
  });
}

// Build the list of subject buttons
function renderList() {
  const visible = getVisibleSubjects();
  listEl.innerHTML = "";

  if (visible.length === 0) {
    const empty = document.createElement("li");
    empty.className = "empty";
    empty.textContent = "No subjects match your search.";
    listEl.appendChild(empty);
  }

  visible.forEach(function (subject, index) {
    const li = document.createElement("li");
    const btn = document.createElement("button");

    btn.type = "button";
    btn.className = "subject-item " + subject.type.toLowerCase();
    btn.dataset.id = subject.id;
    if (studied.includes(subject.id)) btn.classList.add("done");
    if (subject.id === selectedId) btn.setAttribute("aria-current", "true");

    btn.innerHTML =
      '<span class="name"></span><span class="code"></span><span class="tick" aria-hidden="true">\u2714</span>';
    btn.querySelector(".name").textContent = (index + 1) + ". " + subject.name;
    btn.querySelector(".code").textContent = subject.code;

    li.appendChild(btn);
    listEl.appendChild(li);
  });

  countEl.textContent = "Showing " + visible.length + " of " + subjects.length + " subjects";
}

// Find a subject in the array by id
function findSubject(id) {
  return subjects.find(function (s) { return s.id === id; });
}

// Show the details of one subject
function showSubject(id) {
  const subject = findSubject(id);
  if (!subject) return;
  selectedId = id;

  document.getElementById("d-code").textContent = subject.code;
  const typeEl = document.getElementById("d-type");
  typeEl.textContent = subject.type;
  typeEl.className = "badge " + subject.type.toLowerCase();

  document.getElementById("detail-title").textContent = subject.name;
  document.getElementById("d-desc").textContent = subject.description;

  // Loop over the topics array
  const topicsEl = document.getElementById("d-topics");
  topicsEl.innerHTML = "";
  subject.topics.forEach(function (topic) {
    const li = document.createElement("li");
    li.textContent = topic;
    topicsEl.appendChild(li);
  });

  studiedBox.checked = studied.includes(id);

  placeholderEl.hidden = true;
  detailEl.hidden = false;
  detailEl.classList.remove("fade-in");
  void detailEl.offsetWidth;            // restart the animation
  detailEl.classList.add("fade-in");

  renderList();
  updateProgress();
}

// Update the progress bar
function updateProgress() {
  const total = subjects.length;
  const done = studied.length;
  const percent = Math.round((done / total) * 100);

  document.getElementById("progress-label").textContent = done + " of " + total + " studied (" + percent + "%)";
  document.getElementById("progress-fill").style.width = percent + "%";
  document.getElementById("progress").setAttribute("aria-valuenow", percent);
}

// Move to the next (+1) or previous (-1) visible subject
function moveSelection(step) {
  const visible = getVisibleSubjects();
  if (visible.length === 0) return;

  let index = visible.findIndex(function (s) { return s.id === selectedId; });
  index = index === -1 ? (step > 0 ? 0 : visible.length - 1)
                       : (index + step + visible.length) % visible.length;

  showSubject(visible[index].id);
  focusSelectedButton();
}

function showRandomSubject() {
  const visible = getVisibleSubjects();
  if (visible.length === 0) return;
  const pick = visible[Math.floor(Math.random() * visible.length)];
  showSubject(pick.id);
}

function focusSelectedButton() {
  const btn = listEl.querySelector('[aria-current="true"]');
  if (btn) btn.focus();
}

// ---------- 5. EVENTS ----------

// click: choose a subject (one listener for the whole list: event delegation)
listEl.addEventListener("click", function (event) {
  const btn = event.target.closest(".subject-item");
  if (btn) showSubject(Number(btn.dataset.id));
});

// keydown: arrow keys move between subjects
listEl.addEventListener("keydown", function (event) {
  if (event.key === "ArrowDown") { event.preventDefault(); moveSelection(1); }
  if (event.key === "ArrowUp")   { event.preventDefault(); moveSelection(-1); }
});

// input: search while typing
searchEl.addEventListener("input", renderList);

// change: filter by type
filterEl.addEventListener("change", renderList);

// click: Previous, Next, Random buttons
document.getElementById("prev-btn").addEventListener("click", function () { moveSelection(-1); });
document.getElementById("next-btn").addEventListener("click", function () { moveSelection(1); });
document.getElementById("random-btn").addEventListener("click", showRandomSubject);

// change: mark as studied
studiedBox.addEventListener("change", function () {
  if (selectedId === null) return;
  const position = studied.indexOf(selectedId);
  if (studiedBox.checked && position === -1) studied.push(selectedId);
  if (!studiedBox.checked && position !== -1) studied.splice(position, 1);
  renderList();
  updateProgress();
});

// keydown on the page: "/" jumps to the search box
document.addEventListener("keydown", function (event) {
  const typing = ["INPUT", "SELECT", "TEXTAREA"].includes(document.activeElement.tagName);
  if (event.key === "/" && !typing) {
    event.preventDefault();
    searchEl.focus();
  }
});

// ---------- 6. START ----------
document.getElementById("year").textContent = new Date().getFullYear();
renderList();
updateProgress();
