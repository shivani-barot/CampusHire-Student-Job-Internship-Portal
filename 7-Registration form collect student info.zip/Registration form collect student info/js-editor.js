const form = document.getElementById("reg-form");
const password = document.getElementById("password");
const confirmPw = document.getElementById("confirm");
const dob = document.getElementById("dob");
const address = document.getElementById("address");

// Do not allow a future date of birth
dob.max = new Date().toISOString().split("T")[0];

// 1. Show / hide password
const toggleBtn = document.getElementById("toggle-pw");
toggleBtn.addEventListener("click", function () {
  const show = password.type === "password";
  password.type = show ? "text" : "password";
  confirmPw.type = show ? "text" : "password";
  toggleBtn.textContent = show ? "Hide" : "Show";
  toggleBtn.setAttribute("aria-pressed", String(show));
  toggleBtn.setAttribute("aria-label", show ? "Hide password" : "Show password");
});

// 2. Password strength meter
const fill = document.getElementById("meter-fill");
const strengthText = document.getElementById("pw-strength");

password.addEventListener("input", function () {
  const value = password.value;
  let score = 0;
  if (value.length >= 8) score++;
  if (/[A-Z]/.test(value) && /[a-z]/.test(value)) score++;
  if (/[0-9]/.test(value)) score++;
  if (/[^A-Za-z0-9]/.test(value)) score++;

  const labels = ["", "Weak", "Fair", "Good", "Strong"];
  const colors = ["#b3261e", "#b3261e", "#d9a21b", "#7fae3c", "#1e8449"];
  fill.style.width = (value ? score * 25 : 0) + "%";
  fill.style.background = colors[score];
  strengthText.textContent = value ? "Strength: " + labels[score] : "";
  checkConfirm();
});

// 3. Confirm password must match
function checkConfirm() {
  if (confirmPw.value && confirmPw.value !== password.value) {
    confirmPw.setCustomValidity("Passwords do not match");
  } else {
    confirmPw.setCustomValidity("");
  }
}
confirmPw.addEventListener("input", checkConfirm);

// 4. Address character counter
address.addEventListener("input", function () {
  document.getElementById("addr-count").textContent = address.value.length;
});

// 5. Show error messages under each field
function showErrors() {
  form.querySelectorAll("input, select, textarea").forEach(function (field) {
    const key = field.name === "gender" ? "gender" : field.id;
    const box = document.getElementById(key + "-error");
    if (!box) return;
    if (field.type === "radio" && field.name === "gender") {
      const checked = form.querySelector('input[name="gender"]:checked');
      box.textContent = checked ? "" : "Please choose a gender.";
    } else {
      box.textContent = field.validity.valid ? "" : field.validationMessage;
    }
  });
}

form.addEventListener("input", function () {
  if (form.classList.contains("submitted")) showErrors();
});
form.addEventListener("change", function () {
  if (form.classList.contains("submitted")) showErrors();
});

// 6. Submit: validate, then show a summary instead of sending data
const result = document.getElementById("result");

form.addEventListener("submit", function (event) {
  event.preventDefault();
  form.classList.add("submitted");
  checkConfirm();
  showErrors();

  if (!form.checkValidity()) {
    const firstBad = form.querySelector(":invalid");
    if (firstBad) firstBad.focus();
    return;
  }

  const data = new FormData(form);
  const hobbies = data.getAll("hobbies");
  const items = [
    ["Name", data.get("fullname")],
    ["Email", data.get("email")],
    ["Gender", data.get("gender")],
    ["Date of birth", data.get("dob")],
    ["City", data.get("city")],
    ["Course", data.get("course")],
    ["Hobbies", hobbies.length ? hobbies.join(", ") : "None selected"],
    ["Address", data.get("address")]
  ];

  const list = document.getElementById("r-list");
  list.innerHTML = "";
  items.forEach(function (pair) {
    const dt = document.createElement("dt");
    const dd = document.createElement("dd");
    dt.textContent = pair[0];
    dd.textContent = pair[1];
    list.appendChild(dt);
    list.appendChild(dd);
  });

  document.getElementById("r-name").textContent = data.get("fullname");
  form.hidden = true;
  result.hidden = false;
  result.scrollIntoView({ behavior: "smooth" });
});

// 7. Reset clears the extra UI state too
form.addEventListener("reset", function () {
  form.classList.remove("submitted");
  form.querySelectorAll(".error").forEach(function (e) { e.textContent = ""; });
  fill.style.width = "0";
  strengthText.textContent = "";
  document.getElementById("addr-count").textContent = "0";
  confirmPw.setCustomValidity("");
});

document.getElementById("back-btn").addEventListener("click", function () {
  form.reset();
  result.hidden = true;
  form.hidden = false;
  window.scrollTo({ top: 0, behavior: "smooth" });
});

// Footer year
document.getElementById("year").textContent = new Date().getFullYear();
